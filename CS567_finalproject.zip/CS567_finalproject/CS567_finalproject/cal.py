import cmath
import math

class ComplexCalculator:
    def add(self, num1, num2):
        return num1 + num2

    def subtract(self, num1, num2):
        return num1 - num2

    def multiply(self, num1, num2):
        return num1 * num2

    def divide(self, num1, num2):
        return num1 / num2

    def exponentiate(self, num, exp):
        return num ** exp

    def square_root(self, num):
        return cmath.sqrt(num)

    def absolute(self, num):
        return abs(num)

    def conjugate(self, num):
        return num.conjugate()

    def sine(self, num):
        return cmath.sin(num)

    def cosine(self, num):
        return cmath.cos(num)

    def tangent(self, num):
        return cmath.tan(num)

    def natural_logarithm(self, num):
        return cmath.log(num)

    def logarithm_base_10(self, num):
        return cmath.log10(num)

    def arc_sine(self, num):
        return cmath.asin(num)

    def arc_cosine(self, num):
        return cmath.acos(num)

    def arc_tangent(self, num):
        return cmath.atan(num)

# Testing the calculator
if __name__ == "__main__":
    calc = ComplexCalculator()

    num1 = complex(3, 2)
    num2 = complex(1, 4)

    print("Addition:", calc.add(num1, num2))
    print("Subtraction:", calc.subtract(num1, num2))
    print("Multiplication:", calc.multiply(num1, num2))
    print("Division:", calc.divide(num1, num2))
    print("Exponentiation:", calc.exponentiate(num1, 2))
    print("Square Root of", num1, ":", calc.square_root(num1))
    print("Absolute Value of", num1, ":", calc.absolute(num1))
    print("Conjugate of", num1, ":", calc.conjugate(num1))
    print("Sine of", num1, ":", calc.sine(num1))
    print("Cosine of", num1, ":", calc.cosine(num1))
    print("Tangent of", num1, ":", calc.tangent(num1))
    print("Natural Logarithm of", num1, ":", calc.natural_logarithm(num1))
    print("Logarithm Base 10 of", num1, ":", calc.logarithm_base_10(num1))
    print("Arc Sine of", num1, ":", calc.arc_sine(num1))
    print("Arc Cosine of", num1, ":", calc.arc_cosine(num1))
    print("Arc Tangent of", num1, ":", calc.arc_tangent(num1))
