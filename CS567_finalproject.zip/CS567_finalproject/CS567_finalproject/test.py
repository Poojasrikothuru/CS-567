import unittest
from cal import ComplexCalculator

class TestComplexCalculator(unittest.TestCase):

    def setUp(self):
        self.calc = ComplexCalculator()

    def test_addition(self):
        num1 = complex(3, 2)
        num2 = complex(1, 4)
        self.assertEqual(self.calc.add(num1, num2), complex(4, 6))

    def test_subtraction(self):
        num1 = complex(3, 2)
        num2 = complex(1, 4)
        self.assertEqual(self.calc.subtract(num1, num2), complex(2, -2))

    def test_multiplication(self):
        num1 = complex(3, 2)
        num2 = complex(1, 4)
        self.assertEqual(self.calc.multiply(num1, num2), complex(-5, 14))

    def test_division(self):
        num1 = complex(3, 2)
        num2 = complex(1, 4)
        # Adjust the expected value based on the calculated result
        self.assertAlmostEqual(self.calc.divide(num1, num2), complex(0.647, -0.588), places=3)

    def test_exponentiation(self):
        num1 = complex(3, 2)
        exp = 2
        # Update the expected value based on the correct result
        self.assertEqual(self.calc.exponentiate(num1, exp), complex(5, 12))

if __name__ == '__main__':
    unittest.main()
